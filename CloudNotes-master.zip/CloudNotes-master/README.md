# Cloud Certifications Notes.

<!-- Place this tag where you want the button to render. -->
<a class="github-button" href="https://github.com/rishabkumar7/AWSNotes" data-icon="octicon-star" data-size="large" aria-label="Star rishabkumar7/AWSNotes on GitHub">Star</a> <a class="github-button" href="https://github.com/rishabkumar7/AWSNotes/subscription" data-icon="octicon-eye" data-size="large" aria-label="Watch rishabkumar7/AWSNotes on GitHub">Watch</a> <!-- Place this tag where you want the button to render. -->
<a class="github-button" href="https://github.com/rishabkumar7/cloudnotes/issues" data-icon="octicon-issue-opened" data-size="large" aria-label="Issue rishabkumar7/cloudnotes on GitHub">Issue</a> 

## Notes for AWS Certifications.
- [AWS Cloud Practitioner](/CloudNotes/CPP.html)
- [AWS Solutions Architect Associate](/CloudNotes/SAA.html)
- [AWS Developer Associate](/CloudNotes/CDA.html)

## Notes for Azure Certfications.
- Coming Soon

## Notes for OCI Certifications.
- [OCI Foundations Associate](/CloudNotes/OCIFA.html)





I will be adding notes for other Exams.

Please check out these amazing CheatSheets:
- [TutorialDojo Cheat Sheets](https://tutorialsdojo.com/aws-cheat-sheets/)
- [DigitalCloud Cheat Sheets](https://digitalcloud.training/certification-training/)
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
